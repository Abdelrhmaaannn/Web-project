
// Function that triggers when "Buy Now" button is clicked
function buyBook(bookTitle) {
    alert(`You have clicked on the "Buy Now" button for: ${bookTitle}`);
}